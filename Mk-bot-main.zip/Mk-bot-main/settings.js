///SC RECODE BY DINZID VyL x Malvin King
// © RECODE BY Malvin King 2022 - 2025
// Cr : @XdKing2 
//DO NOT DELETE CREDITS!! DELETE? = I'LL ENCRYPT EVERYTHING!! 

const chalk = require("chalk")
const fs = require("fs")
//auto presence update
global.autoTyping = false //auto typing in group chat (true to enable, false to disable)
global.autoRecord = false //auto recording (true to enable, false to disable)
global.autoblockmorroco = true //auto block 212 (true to enable, false to disable)
global.autokickmorroco = true //auto kick 212 (true to enable, false to disable) 
global.antispam = false //auto kick spammer (true to enable, false to disable)
//////////////////////////////////////////////////////////////////////////////////

//LIMIT//

//=========EDIT THE THUMBNAIL MENU & ALLMENU PART==========//

global.thumbnail = 'https://files.catbox.moe/7ud9t7.jpg', //YOUR MENU THUMBNAIL
global.dinzmenu = 'https://files.catbox.moe/33o6jd.jpg', //YOUR MENU BUTTON THUMBNAIL
/////////////////////////////////////////////////////////////////////////////////

//LIMIT//

/////////////////////// WELCOME SETTINGS ///////////////
global.wlcmimg = 'https://files.catbox.moe/641pvo.jpg'
global.leftimg = 'https://files.catbox.moe/33o6jd.jpg'
global.wlcm = true //FOR AUTO WELCOME
global.textwlcm = `
┌─┉─ • ─┉─  ── .✦
│Welcome new member, introduction please!
│Name:
│Ask:
│Age:
│Make sure to introduce yourself properly ૮₍꜆꜄ ˃ ³ ˂ ₎ა
└─┉─¡! • !¡─┉─ ── .✦
`

///////////////////)/)) FAKE REPLY/FAKE QUOTED //////////////////))/
global.replyyoimiya = 'https://files.catbox.moe/641pvo.jpg'
global.replyMalvinID = 'https://files.catbox.moe/33o6jd.jpg'
global.replydinz = 'https://files.catbox.moe/7ud9t7.jpg'
global.reply = 'https://files.catbox.moe/33o6jd.jpg'
global.replyviex = 'https://files.catbox.moe/641pvo.jpg'

//////////////////////YOUR MENU DISPLAY SETTINGS//////////////////
global.ig = '@techlord01' //YOUR INSTAGRAM NAME
global.yt = 'malvintech2' //YOUR YOUTUBE NAME, IF NONE THEN LEAVE BLANK
global.ttowner = 'malvinquotes' //YOUR TIKTOK NAME
global.ownername = 'ᴅᴇᴠ : ᴍᴀʟᴠɪɴ ᴋɪɴɢ' //YOUR NAME
global.owner = ['263780166288'] // ALSO SET THIS IN DATABASE FOLDER 
global.ownernomer = '263780166288' //YOUR NUMBER
global.socialm = 'GitHub: -'
global.location = 'Indonesia' 
global.nameCreator = 'ᴅᴇᴠ : ᴍᴀʟᴠɪɴ ᴋɪɴɢ'
/////////////////////////////////////////////////////////////////////////////////


//==================BOT SETTINGS===========================\\
global.botname = "MK | BOT" //YOUR BOT NAME
global.ownernumber = '263780166288' //YOUR NUMBER
global.botnumber = '263780166288' //YOUR NUMBER
global.ownername = 'ᴅᴇᴠ : ᴍᴀʟᴠɪɴ ᴋɪɴɢ' //YOUR NAME
global.idSaluran = "120363398430045533@newsletter" //YOUR CHANNEL ID
global.idch = "120363398430045533@newsletter" //YOUR CHANNEL ID
global.chat = '120363398430045533@newsletter'
global.namaSaluran = "MK | MD"
global.linkSaluran = "https://whatsapp.com/channel/0029VbA6MSYJUM2TVOzCSb2A"
global.ownerNumber = ["263780166288@s.whatsapp.net"] //YOUR NUMBER
global.ownerweb = "" //YOUR WEB//OPTIONAL
global.websitex = "" //OPTIONAL
global.wagc = "https://whatsapp.com/channel/0029VbA6MSYJUM2TVOzCSb2A"
global.wach = 'https://whatsapp.com/channel/0029VbA6MSYJUM2TVOzCSb2A'
global.saluran = "https://whatsapp.com/channel/0029VbA6MSYJUM2TVOzCSb2A"
global.themeemoji = '🪀'
global.wm = "Malvin King Tha Best"
global.botscript = 'ʙᴏᴛ sᴄʀɪᴘᴛ ɪɴ\nlink : https://whatsapp.com/channel/0029VbA6MSYJUM2TVOzCSb2A'
global.packname = "Made With ❤️ By"
global.author = "\n\nLordMk\n Dev : Malvin"
global.creator = "263780166288@s.whatsapp.net"


////////////////////////////////////////////////////////

global.mess = {
    wait: "*_ᴡᴀɪᴛ ᴛɪʟʟ ɪᴛ'ᴅ ᴘʀᴏᴄᴇssᴇᴅ._*",
    success: "Success!",
    on: "ᴇɴᴀʙʟᴇᴅ",
    off: "ᴅɪsᴀʙʟᴇᴅ",
    query: {
        text: "Where's the text, please?",
        link: "Where's the link, please?",
    },
    error: {
        feature: "Sorry, there is a feature error. Please contact the bot developer via chat for it to be fixed.",
    },
    only: {
        group: "Sorry, this feature is only available in groups.",
        private: "Sorry, this feature is only available in private chats.",
        owner: "Sorry, this feature is only available for the bot owner.",
        admin: "Sorry, this feature is only available for bot admins.",
        badmin: "Sorry, it looks like you are not an admin, so you can't use this feature.",
        premium: "Sorry, you are not a premium user yet. To become a premium user, please contact the owner using .owner.",
    }
}

//========================================\\
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

//new
global.prefix = ['.']
global.sessionName = 'session' // Jangan di ubah takut nanti error
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.filename = "©ᴅᴇᴠ : ᴍᴀʟᴠɪɴ ᴋɪɴɢ"
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
